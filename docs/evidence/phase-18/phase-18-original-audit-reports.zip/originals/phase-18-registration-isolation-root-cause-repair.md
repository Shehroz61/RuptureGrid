# PHASE 18 — REGISTRATION-ISOLATION ROOT-CAUSE REPAIR

Session: 17 October 2026. Scope: integration fixture ownership and rerunnable regressions. Production registration policy, Phase 18 application implementation and architecture are preserved. No Phase 18 acceptance or Phase 19 work is claimed.

External evidence bundle: [phase18-registration-closure](C:/Users/shehr/.codex/visualizations/2026/10/16/01a1467f-8e44-73f2-b086-0801a9f9eb92/phase18-registration-closure). The commands below run from the repository root; evidence scripts accept the bundle directory as an argument. Counts distinguish collection, execution and deliberate shuffle filters.

## A. Original three failures and preserved evidence

The preceding repair's first full invocation remains unchanged: **444 PASS, 3 FAIL, 0 SKIPPED**, exit 1. Its three failures were all in `multi-worker.test.ts`: duplicate competing delivery; crash/lease-expiry takeover; and ambiguous mutating crash. The first full failure log and preceding report were preserved, without another monolithic attempt in that repair.

The recycled origin was `http://127.0.0.1:64764`. A prior Commerce target `59b83a35-14d1-4aaa-9f0d-c5d406beb035`, named `checkout-zero-demo-demomux4co25`, was created on 2026-10-06T20:16:18.600Z. The old catch-all fallback returned its ID after registration failed. Its manifest declared COMMERCE_ADMIN_TOKEN and DEMO_COMMERCE_SIGNING_SECRET; the multi-worker experiment had no corresponding platform grant policy. All three attempts raised CredentialAuthorizationError during createExperiment, before a definition or run was written. They never reached the intended worker assertions.

Before source edits, this session reproduced all three original makeRun inputs against a migrated disposable database containing a copy of the exact offending registration. Each rejected with zero definitions and zero runs; the source row was unchanged and the probe database was dropped. See `original-three-failures.log` and `multi-worker-first-failure-diagnosis.json`. The diagnostic command's exit 0 means the expected rejection was observed, not that a multi-worker test passed. All 257 previously hashed historical evidence/report files remain byte-identical.

## B. Shared registration ownership root cause

ADR-0024 makes the normalized origin authority the credential authorization principal. The target ID identifies the durable registration; environment, contract, declared credential-reference names, manifest provenance and explicit per-origin grants constrain its use. A display name, equal origin or compatible manifest does not transfer ownership to another fixture.

The persistent developer Control database shared globally unique origins across files and previous sessions. OS port reuse makes a newly bound HTTP listener collide with an old registration even when files run serially. Several inline and shared helpers caught registration errors and adopted a row by origin; some guarded only contract kind or non-null manifest. Those compatibility checks did not establish fixture ownership. Lazy ID caches then retained the adopted ID. Golden cleanup also deleted rows by a display-name pattern, potentially affecting another fixture. The earlier Redis repair exposed this pre-existing multi-worker defect when the full suite advanced; it did not create that foreign Commerce registration.

## C. Complete fixture inventory

All 44 integration files were inspected/classified: 21 use the shared owned runtime, 12 use strict fresh registration paths, and 11 create no target registrations. `fixture-inventory.json` records acquisition, namespace, reuse, cleanup and source call locations for every file; `registration-calls-before.txt` and `registration-calls-after.txt` retain the searches.

| Integration file | Collected cases | Registration path |
| --- | ---: | --- |
| `api-health.test.ts` | 5 | No target registration |
| `controlled-faults.test.ts` | 6 | Owned runtime |
| `databases.test.ts` | 7 | No target registration |
| `demo-controlled-faults.test.ts` | 8 | No target registration |
| `demo-db-domain.test.ts` | 8 | No target registration |
| `demo-execution.test.ts` | 2 | Owned runtime |
| `demo-health.test.ts` | 3 | No target registration |
| `demo-incident-zero.test.ts` | 41 | No target registration |
| `evidence-capture.test.ts` | 4 | Owned runtime |
| `evidence-invariants.test.ts` | 9 | Owned runtime |
| `execution-mechanics.test.ts` | 7 | Owned runtime |
| `fixture-registration-isolation.test.ts` | 10 | Owned runtime |
| `forensics.test.ts` | 9 | Owned runtime |
| `golden-incident-zero.test.ts` | 15 | Owned runtime |
| `logger.test.ts` | 2 | No target registration |
| `multi-worker.test.ts` | 3 | Owned runtime |
| `observation-identity.test.ts` | 6 | Shared DB; strict create |
| `ownership.test.ts` | 5 | Shared DB; strict create |
| `phase14-generic-evidence.test.ts` | 12 | Existing throwaway DB; strict create |
| `phase15-generic-invariants.test.ts` | 13 | Owned runtime |
| `phase16-demo-commerce.test.ts` | 36 | Owned runtime |
| `phase17-aggregation.test.ts` | 3 | Owned runtime |
| `phase17-b1-provenance-revision.test.ts` | 21 | Shared DB; strict create |
| `phase17-b1-worker-emergency.test.ts` | 21 | Owned runtime |
| `phase17-b2-derivation-completeness.test.ts` | 27 | Shared DB; strict create |
| `phase17-b3-validate-authoritative.test.ts` | 14 | Shared DB; strict create |
| `phase17-c-run-owned-eligibility.test.ts` | 19 | Owned runtime |
| `phase17-cli.test.ts` | 23 | Shared DB; strict create |
| `phase17-d-report-finalization.test.ts` | 7 | Shared DB; strict create |
| `phase17-e1-anchor-s-matrix.test.ts` | 27 | Owned runtime |
| `phase17-e2-worker-catch.test.ts` | 1 | Shared DB; strict create |
| `phase17-e3-d20-precedence.test.ts` | 4 | Shared DB; strict create |
| `phase18-audit-blockers.test.ts` | 28 | Owned runtime |
| `phase18-initialization.test.ts` | 1 | No target registration |
| `phase18-replay-commerce.test.ts` | 11 | Shared DB; strict create |
| `phase18-replay-fintech.test.ts` | 5 | Owned runtime |
| `phase9-browser.test.ts` | 2 | Owned runtime |
| `queue.test.ts` | 4 | No target registration |
| `redis-outage-reconciliation.test.ts` | 2 | Owned runtime |
| `showcase-browser.test.ts` | 1 | Owned runtime |
| `snapshot-immutability.test.ts` | 5 | Shared DB; strict create |
| `target-manifest.test.ts` | 15 | Owned runtime |
| `web.test.ts` | 3 | No target registration |
| `worker-startup.test.ts` | 2 | No target registration |

The remaining shared getControlPrisma cache is a client for the fixed configured source database, not a target-ID cache. The new runtime never changes process.env. uniqueTestOrigin returns only an unbound origin; it never returns an existing target. Strict live binding paths may reject/rebind before creating their own registration, and do not adopt IDs. Phase 14 retains its already isolated database. Historical CLI replay intentionally uses the explicit reproduction/snapshot target binding.

Shared helper inventory: owned-control-fixture owns database, queue prefix, acquisition receipts and teardown; control-db-provision applies the committed migrations and drops only its UUID-created database; phase4-harness and golden-harness require an explicit owner. The unsafe registerLocalFixtureTarget export and all integration origin-adoption fallbacks are removed. The production Incident Zero operator helper remains unchanged; integration fixtures no longer invoke its origin-reuse path. The production golden runner's experiment lookup runs inside the fixture-owned database.

## D. Exact corrective changes

- Added `helpers/owned-control-fixture.ts`: one migrated Control database and unique queue prefix per runtime, explicit environment propagation, successful own-ID receipts, a synchronous owner/key promise map, input snapshots, normalized metadata comparison, live own-ID binding checks and idempotent cleanup that joins pending acquisitions.
- Same owner/key shares one production registration attempt, including concurrent initialization. A failed attempt remains a visible failure. Changed metadata or grants reject; there is no origin lookup, fallback adoption, hidden retry or automatic metadata repair. Metadata comparison is test-only and in memory; it uses reference names, never credential values, and adds no ADR-0027 credential fingerprint mechanism.
- Converted all reuse-capable fixture callers deliberately, including Fintech/browser/golden, manifest, aggregation, multi-worker, Redis-outage and execution suites. Producers, consumers, child workers and API clients receive the same owned database URL and queue prefix. Previously isolated Redis/mechanics/blocker fixtures now use the common contract.
- Removed broad golden registration deletion. Cleanup drops only the owned database after callers stop their resources. Multi-worker and demo-execution teardown now joins actual child exits; multi-worker's fixed 100/200 ms post-kill sleeps are removed.

No production registration or grant enforcement changed. No assertions or titles were removed from the 39 accepted integration files. All 447 prior collected cases remain; the only additional cases are the 10 new ownership regressions. Both accepted Checkout Zero scenario files are byte-identical. Application/docs entry hashes and all 61 candidate hashes frozen for verification remain unchanged.

## E. Authorized reuse proof

The first focused invocation passed **28 tests in 3 files**, exit 0: the exact three multi-worker cases, 15 manifest-neighbor cases and 10 new PostgreSQL regressions. See `focused-original-and-registration.log`.

The new concurrent regression starts eight real acquisitions behind a PostgreSQL SHARE lock, observes one blocked RowExclusive registration writer, releases the barrier, and checks one registration/origin and one returned ID. Repeated acquisition across normalized origin spellings succeeds. Caller mutation of returned metadata cannot alter the ownership receipt. Origin, environment, credential-reference and platform-grant changes reject. Altered stored metadata rejects without repair. These are rerunnable real-database tests in `fixture-registration-isolation.test.ts`.

## F. Foreign refusal proof

An identical request under another key cannot claim the owned origin. A registration created outside the acquisition map remains foreign even when its metadata is identical: first and repeated acquisition reject with the same production registration error, the row remains unchanged, and no run is created. Two independent namespaces may each register the same origin, but receive distinct own IDs. Closing one cannot invalidate the other.

The Redis negative regression also passed in both cross-suite orders: production registration refuses the foreign origin; attempting an experiment against the deliberately incompatible foreign manifest rejects at inspection[0].roleId with ManifestValidationError, writes no definition/run, and preserves the row. The three original historical foreign registrations were independently rehashed after verification and are unchanged (`foreign-rows-after.json`).

## G. Multi-worker, Redis-outage and cross-suite isolation

All three original multi-worker assertions now reach actual worker/HTTP behavior (including the full invocation): one real execution for competing deliveries; crashed lease recovery with a newer fencing token; and INDETERMINATE mutating ambiguity without blind redispatch. The Redis positive case genuinely stops/restores the exact configured container and proves durable work reconciliation. Seven execution-mechanics cases retain their original infrastructure semantics.

The focused cross-suite command selects multi-worker, Redis-outage, execution-mechanics, target-manifest and fixture-registration-isolation with `--sequence.shuffle.files --sequence.seed <seed> --reporter=verbose` using the normal integration config:

- Seed 18031: 37 PASS, 0 FAIL, 0 SKIPPED, 5 files, exit 0. Actual file order: `fixture-registration-isolation.test.ts` → `redis-outage-reconciliation.test.ts` → `execution-mechanics.test.ts` → `multi-worker.test.ts` → `target-manifest.test.ts`.
- Seed 18032: 37 PASS, 0 FAIL, 0 SKIPPED, 5 files, exit 0. Actual file order: `fixture-registration-isolation.test.ts` → `multi-worker.test.ts` → `target-manifest.test.ts` → `execution-mechanics.test.ts` → `redis-outage-reconciliation.test.ts`.

File parallelism stays false because the outage takes down the shared Redis service. The required concurrency occurs inside the real multi-process workers and acquisition tests. No arbitrary sleeps, timeout inflation, skipped tests or weakened checks were introduced.

## H. Full unfiltered integration gate

Command: **`pnpm test:integration`**, invoked once after the repair. Start 2026-10-17T11:58:13.1775862+05:00; finish 2026-10-17T12:16:36.2023478+05:00; command duration 1103.025 seconds, including its normal build.

**456 PASS, 1 FAIL, 0 SKIPPED; 43 files PASS, 1 files FAIL; exit 1.** Vitest: 1015.36s (transform 2.75s, setup 0ms, import 36.71s, tests 962.01s, environment 7ms). No file or test-name filter was applied. The complete log is `integration-full.log`; its byte-identical preserved copy is `integration-first-failure-preserved.log`, with the first six gate records in `gates-at-first-failure.json`. Command/exit/timing records remain in `gate-results.json`. Collection independently accounts for 457 cases in 44 files. Focused success is not substituted for this result.

The sole full-run failure was `phase17-b1-worker-emergency.test.ts`, case “a real HTTP mutation reaches the receiver, is not retried, and never becomes KNOWN_ABSENT”. It failed at strict registration before sending HTTP: origin `http://127.0.0.1:54476` belonged to target `c20bd338-4301-4a9e-ba2d-45a3ab8c2000`, display name `b1-prov-target-1791835977865-154588`, created 2026-10-12T20:12:57.875Z. This is another consequence of a shared persistent origin namespace, not foreign adoption or a production authorization defect. The initial inventory correctly identified strict creation but did not eliminate this live binding collision.

The source registration was copied into a migrated diagnostic database; strict production registration reproduced TargetRegistrationError with one target, zero definitions and zero runs. Its source hash remained unchanged, and the diagnostic database was dropped. See `b1-collision-diagnosis.json` and the preserved source `b1-source-at-first-failure.ts`.

After preserving the full failure, the entire B1 file was moved to the shared runtime **per case**. This isolates both historical foreign origins and other cases' metadata-only origins from its live receiver. All original assertions, timeout budgets and production calls remain. The focused B1/ownership invocation then passed **31 cases, 0 failures, 0 skips in 2 files, exit 0**; targeted lint and TypeScript checks passed. See `post-full-b1-and-ownership.log`, `post-full-fixture-typecheck.log` and `post-full-source.json`.

**No second monolithic invocation was performed. The full result describes the pre-extension candidate; the final candidate has not passed the full integration gate. Focused success does not close this verification blocker.**

## I. Exact shuffled gate

The exact previous five-file command, test-name expression, `--sequence.shuffle --sequence.seed 18027 --reporter=verbose`, was rerun. Result: **59 PASS, 0 FAIL, 8 intentionally filtered, exit 0**. No setup skip is claimed. The unchanged expression selects 59 of the five files' 67 collected cases; the eight excluded case names are recorded in `inventory-and-preservation.json`. They are exercised by the unfiltered full run. See `shuffle.log`.

## J. Commerce, Fintech, ADR-0026 and Phase 17 preservation

The full-run Commerce proof uses original run `557c2eea-fb34-4252-a00a-ff9fc7723ba4` and replay `019ed044-a0e6-4e46-95a4-f91933d637f0`, both snapshot `8f27c76f-37a5-4f58-822e-ffabb4004796`, content hash `338bfc09dfb6a294d86897d76686ea7f126ad7b566df6398d19f27d68305f93a`. Actual CLI reports were retained before test cleanup, schema-validated and independently checked against durable PostgreSQL state. Original exit 1, replay exit 0; both runs COMPLETED/COMPLETED and certified. Both bound invariants change FAIL to PASS on that exact snapshot. The no-fix control remains failing.

The independent check rehashes every raw observation/link and the original full durable frame; the original history remains unchanged. It checks actual overlapping processing attempts and target-observed configuration facts. The vulnerable execution has two accepted orders/reservations and remaining stock -1; the fixed execution has one each and stock 0. The approved mode-neutral snapshot permits the same target instance to progress from VULNERABLE to SECURE through the target-owned fix interface; its processing revision changes from the captured original revision to the captured replay revision. Frozen snapshot bytes and target instance remain unchanged. Raw observation counts are 16/16, physical submit invocations 2/2. These facts come from captured target inspection evidence, not invented requests or post-hoc test writes. See `durable-proof-check.json` and `business-proof-<runId>.json`.

Historical Fintech CLI replay was executed again after the full/shuffled/standalone gates: VULNERABLE reproduction `f3fdc9eb-ac62-47f4-ad54-969f5405380f` → new run `e57eed9b-acd1-48ff-b077-79edfcc33be0`, actual CLI exit 1; SECURE reproduction `38700c1e-fa08-4f05-96fc-35fc8b9c3b7b` → new run `05cbb33b-2302-4a95-9316-1a233c72071c`, actual CLI exit 0. Both retain their original snapshot IDs/hashes, preserve their source reproduction records, and have fresh independently checked evidence. The probe exits 0 only when the expected vulnerable exit 1 and secure exit 0 are observed. See `fintech-cli-probe-VULNERABLE-SECURE-results.json` and `fintech-independent-recheck.json`.

The independent Commerce and Fintech checks verify own completed evaluation batches, invariant/evaluator/subject bindings, current pointers, evidence heads and certification watermarks. Historical Fintech retains INV-IZ-1, INV-DF-1 and INV-DF-2 under the accepted v1 compatibility path. The full gate includes **167 Phase 17 cases across 11 files: 166 PASS and the one B1 failure above** (B1 subsequently passes all 21 cases in the focused invocation), 28 Phase 18 hostile blocker cases, 11 Commerce cases, five Fintech lifecycle cases and the real concurrent initialization regression. The preceding repair's persisted Commerce same-snapshot proof was also independently rechecked after this session's runs, using copied receipts and unchanged source evidence.

## K. Remaining verification gates

| Required command | Exit | Seconds |
| --- | ---: | ---: |
| `pnpm format:check` | 0 | 9.500 |
| `pnpm lint` | 0 | 45.579 |
| `pnpm typecheck` | 0 | 159.768 |
| `pnpm test:unit` | 0 | 35.576 |
| `pnpm build` | 0 | 108.238 |
| `pnpm test:integration` | 1 | 1103.025 |
| `pnpm exec vitest run --config tests/integration/vitest.config.ts tests/integration/phase18-audit-blockers.test.ts tests/integration/phase18-replay-commerce.test.ts tests/integration/phase14-generic-evidence.test.ts tests/integration/phase15-generic-invariants.test.ts tests/integration/phase17-aggregation.test.ts -t "Phase 18 audit blockers\|Phase 18 approved mode-preserving amendment\|Phase 14\|Phase 15\|Phase 17.*monotone" --sequence.shuffle --sequence.seed 18027 --reporter=verbose` | 0 | 193.529 |
| `pnpm incident-zero:verify` | 0 | 136.318 |
| `pnpm controlled-faults:verify` | 0 | 128.328 |

The unit run passed 767 tests in 60 files, with zero failures or skips. Migration status and schema diff: all six commands exit 0; 9 Control, 4 Fintech and 3 Commerce migrations are current, with no schema difference and no schema push. The six final evidence commands all exit 0. The broad format/lint/typecheck/unit/build gates precede the B1-only extension; its changed integration setup received targeted lint/typecheck and the 31-case real-database focused check. This distinction does not upgrade the failed full gate. The fresh credential canary verifier exits 0, with outputContainsCanary=false; the transient value is never persisted by the evidence script. Candidate credential scanning found zero private credential leaks. `git diff --check` passed before gates and is rerun for the final inventory.

Preserved corrections before the full gate: the initial targeted typecheck found the remaining golden-harness caller of the old helper signature; it was corrected and the targeted check then passed. The first repository format check reported one fixture file; it was formatted and the subsequent complete format gate passed. These logs remain in the bundle. No failing full run was retried. Infrastructure health and final exit records are retained separately.

## L. Current Git inventory and risks

HEAD and dereferenced phase-17-accepted remain `eb95c157824f8990be609311a18c668e52ec2b76`; tag object `dc49a32c060635c071848efb7508b3251ec23b5b`. The index remains empty. The final candidate contains **63 paths: 40 tracked modifications and 23 untracked files**, including this report. The entry candidate had 42 paths; its production/application/docs files and historical reports were preserved. `git-final.json` lists every current path, status and SHA-256 and checks the original full-run frozen source, the separately hashed post-full B1 extension and 257 historical hashes. The stored B1 source at the first failure is checked against the unchanged accepted HEAD version.

The shared fixture requires a local/CI PostgreSQL identity able to create and drop its own test databases, as the existing throwaway helper already required. It runs the committed migration SQL and never resets the source database or another suite's registration. Some Demo ports and the Redis outage remain shared service resources, so the integration config deliberately keeps files serial. Ordering was varied; unrestricted parallel file execution is not claimed. Most fixture databases are disposable; the new Commerce lifecycle and historical CLI replay receipts refer to durable source-database runs available for independent recheck. No schema, dependency, production registration-policy or Phase 19 change was added by this repair.

Nothing was staged, committed, tagged or pushed. No Phase 18 acceptance marker was created.

## M. Final readiness verdict

**NOT READY — BLOCKERS REMAIN**

The remaining blocker is verification of the final candidate by a successful complete unfiltered integration invocation. The preserved full run failed; no later focused result substitutes for it. Phase 18 is not accepted.
